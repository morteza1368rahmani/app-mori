package com.template.webapp

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

/**
 * The only screen of every generated app. All customization (URL, colors,
 * pull-to-refresh on/off, etc.) comes from BuildConfig fields, which Gradle
 * generates at compile time from template/config.properties (see that file
 * and build.gradle.kts). This class itself never changes between generated
 * apps — only config.properties does.
 */
class WebViewActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)

        val primaryColor = safeParseColor(BuildConfig.PRIMARY_COLOR)
        val primaryColorDark = safeParseColor(BuildConfig.PRIMARY_COLOR_DARK)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)

        window.statusBarColor = primaryColorDark
        swipeRefresh.setBackgroundColor(primaryColor)

        swipeRefresh.setOnRefreshListener { webView.reload() }
        swipeRefresh.isEnabled = BuildConfig.PULL_TO_REFRESH

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = BuildConfig.USE_LOCAL_SITE
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) android.view.View.VISIBLE else android.view.View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                swipeRefresh.isRefreshing = false
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val requestUrl = request.url
                val scheme = requestUrl.scheme ?: return false

                if (scheme != "http" && scheme != "https") {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, requestUrl))
                        true
                    } catch (e: Exception) {
                        true
                    }
                }

                if (!BuildConfig.ALLOW_EXTERNAL_LINKS && !BuildConfig.USE_LOCAL_SITE) {
                    val homeHost = Uri.parse(BuildConfig.SITE_URL).host
                    if (requestUrl.host != null && requestUrl.host != homeHost) {
                        startActivity(Intent(Intent.ACTION_VIEW, requestUrl))
                        return true
                    }
                }
                return false
            }
        }

        if (BuildConfig.USE_LOCAL_SITE) {
            webView.loadUrl("file:///android_asset/site/index.html")
        } else {
            webView.loadUrl(BuildConfig.SITE_URL)
        }
    }

    private fun safeParseColor(hex: String): Int = try {
        android.graphics.Color.parseColor(hex)
    } catch (e: Exception) {
        android.graphics.Color.parseColor("#2962FF")
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
