pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "WebToApkGen"
// The whole tool is now just this one module: a WebView shell configured
// entirely via template/config.properties and built+signed for real by
// the Android Gradle Plugin (see README.md).
include(":template")
